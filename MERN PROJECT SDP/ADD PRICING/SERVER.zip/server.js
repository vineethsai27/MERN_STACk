                                              Mern Stack development

M -> Mongo DB -> Data Base(No SQL) 
E -> Express  -> BackEnd output in Browser --> Framework
R -> React JS -> FrontEnd -------------------> Package/Module
N -> Node JS  -> BackEnd --------------------> Runtime Environment



                                               Install NodeJs


node --version

create file as server.js and print welcome
Run the file as "node server.js"