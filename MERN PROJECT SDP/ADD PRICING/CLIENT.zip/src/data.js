export const ComputerScience = [
  {
    uuid: 1,
    displayName: "DELL",
    imageUrl: "assets/CSE-BLOCK.jpg",
    description: "",
    programsOffered: [
      
    ],
    hod: "",
  },
];


export const Electrical = [  {
    uuid: 2,
    displayName: "LENOVO",
    imageUrl: "assets/ELECTRICAL-BLOCK.jpg",
    description:"",
    programsOffered: [
      
    ],
    hod: "",
  }


]
export const Mechanical = [ {
    uuid: 3,
    displayName: "MAC",
    imageUrl: "assets/MECH-BLOCK.jpg",
    description:"",
    programsOffered: [
      
    ],
    hod: "",
  },
]
  
export const BioTech = [
  {


    uuid: 4,
    displayName: "HP",
    imageUrl: "assets/BIO-TECH-BLOCK.jpg",
    description:"",
    programsOffered: [
      
    ],
    hod: "",
  },
];
